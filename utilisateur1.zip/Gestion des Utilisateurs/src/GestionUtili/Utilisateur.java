package GestionUtili;



public class Utilisateur extends Personne {
	private Profile profil;
	private String motDePass;
	private String service;
	private String login;

	
	
	public Profile getProfil() {
		return profil;
	}
	public void setProfil(Profile profil) {
		this.profil = profil;
	}
	public String getMotDePass() {
		return motDePass;
	}
	public void setMotDePass(String motDePass) {
		this.motDePass = motDePass;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	
	public String getLogin() {
		return login;
	}

	public void setlogin(String login) {
		this.login = login;
	}

	
	public Utilisateur(String matricule, String nom, String prenom, String email, int telephone, double salaire,
			 String motDePass, String login ,String service) {
		super(matricule, nom, prenom, email, telephone, salaire);
		this.motDePass = motDePass;
		this.login = login;
		this.service = service;
	}
	
	public Utilisateur() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	


/*public double calculerSalaire() {
		if(getProfil().contains("MN")) {
			return getSalaire() + getSalaire() * 0.08;
		}
		else if(getProfil().contains("DG")) {
			return getSalaire() + getSalaire() * 0.15;
		}
		return getSalaire();
	}
*/
	
	
	@Override

	public double calculerSalaire() {
		
		switch(service){
			case "MN":
				double NouveauSalaire = getSalaire() + getSalaire() * 0.08;
				setSalaire(NouveauSalaire);
				return getSalaire();
			
			case "DG":
				NouveauSalaire = getSalaire() + getSalaire() * 0.15;
				setSalaire(NouveauSalaire);
				
				return getSalaire();
				
		default:
					return getSalaire();
		}
		
	}
	
	
	
	
	@Override

	public String affiche() {
		return "\n |Login: " +getLogin()+"\n |MotDePass: " + getMotDePass() + "\n |Service: " + getService()
				+ "\n |Matricule: " + getMatricule() + "\n |Nom: " + getNom() + "\n |Prenom: " + getPrenom()
				+ "\n |Email: " + getEmail() + "\n |Telephone: " + getTelephone() + "\n |Salaire: " + calculerSalaire() + " DH";
	}

	
			
		
		
	
	
	
}
