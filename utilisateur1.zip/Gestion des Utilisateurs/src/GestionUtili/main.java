package GestionUtili;

import java.util.ArrayList;

public class main {

	public static void main(String[] args) {
		
		ArrayList<Utilisateur> utiliListe = new ArrayList<Utilisateur>();
		
		Profile profile1 = new Profile(1,"Aj7F5","MN");
		Profile profile2 = new Profile(2,"F2HK5","MN");
		Profile profile3 = new Profile(3,"Lpms6","MN");
		Profile profile4 = new Profile(4,"F2HK5","CP");
		Profile profile5 = new Profile(5,"Lpms6","DP");
		Profile profile6 = new Profile(6,"Aj7F5","DG");
		Profile profile7 = new Profile(7,"Lpms6","DRH");
		


		Utilisateur U1 = new Utilisateur();
		U1.setMatricule("JLS63");
		U1.setService(profile1.getLibelle());
		U1.setEmail("exple@expmle.com");
		U1.setlogin("exple");
		U1.setMotDePass("exple");
		U1.setNom("exemple");
		U1.setPrenom("exemple");
		U1.setTelephone(1680530);
		U1.setSalaire(1100);
		

		Utilisateur U2 = new Utilisateur();
		U2.setMatricule("LSK76");
		U2.setService(profile2.getLibelle());
		U2.setEmail("exple@expmle.com");
		U2.setlogin("exple");
		U2.setMotDePass("exple");
		U2.setNom("exemple");
		U2.setPrenom("exemple");
		U2.setTelephone(1680530);
		U2.setSalaire(1000);
		

		Utilisateur U3 = new Utilisateur();
		U3.setMatricule("22H2d");
		U3.setService(profile3.getLibelle());
		U3.setEmail("exple@expmle.com");
		U3.setlogin("exple");
		U3.setMotDePass("exple");
		U3.setNom("exemple");
		U3.setPrenom("exemple");
		U3.setTelephone(1680530);
		U3.setSalaire(1000);
		

		Utilisateur U4 = new Utilisateur();
		U4.setMatricule("22H2d");
		U4.setService(profile4.getLibelle());
		U4.setEmail("exple@expmle.com");
		U4.setlogin("exple");
		U4.setMotDePass("exple");
		U4.setNom("exemple");
		U4.setPrenom("exemple");
		U4.setTelephone(1680530);
		U4.setSalaire(1000);
		

		Utilisateur U5 = new Utilisateur();
		U5.setMatricule("22H2d");
		U5.setService(profile5.getLibelle());
		U5.setEmail("exple@expmle.com");
		U5.setlogin("exple");
		U5.setMotDePass("exple");
		U5.setNom("exemple");
		U5.setPrenom("exemple");
		U5.setTelephone(1680530);
		U5.setSalaire(1000);
		

		Utilisateur U6 = new Utilisateur();
		U6.setMatricule("22H2d");
		U6.setService(profile6.getLibelle());
		U6.setEmail("exple@expmle.com");
		U6.setlogin("exple");
		U6.setMotDePass("exple");
		U6.setNom("exemple");
		U6.setPrenom("exemple");
		U6.setTelephone(1680530);
		U6.setSalaire(1000);
		
		
		Utilisateur U7 = new Utilisateur();
		U7.setMatricule("22H2d");
		U7.setService(profile7.getLibelle());
		U7.setEmail("exple@expmle.com");
		U7.setlogin("exple");
		U7.setMotDePass("exple");
		U7.setNom("exemple");
		U7.setPrenom("exemple");
		U7.setTelephone(1680530);
		U7.setSalaire(1000);

		
		utiliListe.add(U1);
		utiliListe.add(U2);
		utiliListe.add(U3);
		utiliListe.add(U4);
		utiliListe.add(U5);
		utiliListe.add(U6);
		utiliListe.add(U7);



		
		System.out.println("||*****|| Liste des Utilisateurs : ||*****||\n \n \n");
		for (int i = 0 ; i<utiliListe.size(); i++) {
			utiliListe.get(i).calculerSalaire();
			System.out.println(utiliListe.get(i).affiche());
		}
		
		
		System.out.println(" \n \n \n ||*****|| Liste des managers :||*****||\n \n \n ");
        for(int i=0; i<utiliListe.size(); i++)
        {
            if(utiliListe.get(i).getService().equals("MN"))
            {
                System.out.println(utiliListe.get(i).affiche());
            }
        }
		
		
		}
	

}
